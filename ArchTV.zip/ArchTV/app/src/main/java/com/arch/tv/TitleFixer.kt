package com.arch.tv

import android.text.Html

/**
 * Tidies up the messy titles some apps publish, for example:
 *   title "Bondi Rescue - S1, E1" + subtitle "Season 1, Episode 1"
 * becomes
 *   title "Bondi Rescue" + subtitle "Season 1, Episode 1".
 */
object TitleFixer {

    class Fixed(val title: String, val subtitle: String)

    private const val SEP_CHARS = ",:;·•|/-–—"
    private const val APP_SEPS = "-–—|:·•"

    private fun isSep(c: Char) = c.isWhitespace() || c in SEP_CHARS
    private fun trimSep(s: String) = s.trim { isSep(it) }

    // kind: 0 = "S1 E1" style, 1 = "1x05", 2 = "Ep 5" only, 3 = "Season 2" only
    private val compiled = listOf(
        0 to "\\b(?:s|season|series)\\s*0*(\\d{1,2})\\s*[,:;·•|/.\\-–—\\s]*\\s*(?:e|ep|episode)\\s*\\.?\\s*0*(\\d{1,3})\\b",
        1 to "\\b(\\d{1,2})x(\\d{2,3})\\b",
        2 to "\\b(?:episode|ep)\\s*\\.?\\s*0*(\\d{1,3})\\b",
        3 to "\\b(?:season|series)\\s*0*(\\d{1,2})\\b"
    ).map { (kind, pat) ->
        Triple(
            kind,
            Regex("[(\\[]\\s*(?:$pat)\\s*[)\\]]", RegexOption.IGNORE_CASE), // wrapped in ( ) or [ ]
            Regex(pat, RegexOption.IGNORE_CASE)
        )
    }

    private class Extract(val season: String?, val episode: String?, val rest: String, val tail: String?)

    private fun extract(input: String): Extract {
        var s = input
        var season: String? = null
        var episode: String? = null
        var tail: String? = null
        for ((kind, bracketed, plain) in compiled) {
            if ((kind == 0 || kind == 1) && (season != null || episode != null)) continue
            if (kind == 2 && episode != null) continue
            if (kind == 3 && season != null) continue
            val m = bracketed.find(s) ?: plain.find(s) ?: continue
            val g = m.groupValues
            when (kind) {
                0, 1 -> {
                    season = g[1]
                    episode = g[2]
                }
                2 -> episode = g[1]
                else -> season = g[1]
            }
            val before = trimSep(s.substring(0, m.range.first))
            val after = trimSep(s.substring(m.range.last + 1))
            if (before.isNotBlank() && after.isNotBlank()) {
                // "Show - S1 E1 - Episode name": keep the show, remember the episode name
                s = before
                if (tail == null) tail = after
            } else {
                s = (before + " " + after).trim()
            }
        }
        return Extract(season, episode, s, tail)
    }

    fun clean(raw: String?): String {
        var s = raw ?: return ""
        if (s.contains('&') || s.contains('<')) {
            s = Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString()
        }
        return s.replace(Regex("\\s+"), " ").trim()
    }

    private fun digits(x: String?): String? {
        val m = Regex("\\d+").find(x ?: return null) ?: return null
        return m.value.trimStart('0').ifEmpty { "0" }
    }

    /** Removes the app's own name ("... - 10 Play") when it's tacked onto a title. */
    private fun stripApp(s: String, app: String): String {
        if (app.isBlank()) return s
        var r = s
        if (r.endsWith(app, true) && r.length > app.length) {
            val head = r.dropLast(app.length)
            if (head.trimEnd().lastOrNull()?.let { it in APP_SEPS } == true) {
                val t = trimSep(head)
                if (t.isNotEmpty()) r = t
            }
        }
        if (r.startsWith(app, true) && r.length > app.length) {
            val rest = r.drop(app.length)
            if (rest.trimStart().firstOrNull()?.let { it in APP_SEPS } == true) {
                val t = trimSep(rest)
                if (t.isNotEmpty()) r = t
            }
        }
        return r
    }

    /** Used when "Fix messy titles" is switched off: show exactly what the app published. */
    fun plain(title: String?, episodeTitle: String?) = Fixed(clean(title), clean(episodeTitle))

    fun fix(
        rawTitle: String?,
        episodeTitle: String?,
        seasonField: String?,
        episodeField: String?,
        app: String
    ): Fixed {
        val t0 = stripApp(clean(rawTitle), app)
        val e0 = stripApp(clean(episodeTitle), app)
        val a = extract(t0)
        val b = extract(e0)

        var title = stripApp(a.rest.ifBlank { t0 }, app)
        val season = digits(seasonField) ?: digits(a.season) ?: digits(b.season)
        val episode = digits(episodeField) ?: digits(a.episode) ?: digits(b.episode)
        val fullTitle = title
        var epNameVar: String? = a.tail ?: b.rest.takeIf { it.isNotBlank() && !it.equals(fullTitle, true) }

        // "Show - Episode name" crammed into the title: split it, but only when it's clearly an episode
        if (season != null || episode != null) {
            val m = Regex("\\s[-–—]\\s").find(title)
            if (m != null) {
                val head = title.substring(0, m.range.first).trim()
                val tailPart = title.substring(m.range.last + 1).trim()
                if (head.isNotBlank() && tailPart.isNotBlank()) {
                    title = head
                    if (epNameVar == null) epNameVar = tailPart
                }
            }
        }
        if (epNameVar != null && epNameVar.equals(title, true)) epNameVar = null // "1923 - 1923" -> "1923"
        val epName = epNameVar

        val se = when {
            season != null && episode != null -> "Season $season, Episode $episode"
            episode != null -> "Episode $episode"
            season != null -> "Season $season"
            else -> ""
        }
        val sub = when {
            epName == null -> se
            se.isEmpty() -> epName
            else -> "$se · $epName"
        }
        return Fixed(title, sub)
    }
}
