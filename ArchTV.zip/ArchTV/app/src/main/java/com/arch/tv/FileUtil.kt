package com.arch.tv

import java.io.File
import java.util.Locale

enum class Kind { VIDEO, AUDIO, IMAGE, OTHER }

object FileUtil {
    private val video = setOf("mp4", "mkv", "webm", "mov", "avi", "m4v", "3gp", "ts", "m3u8")
    private val audio = setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "opus")
    private val image = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp")

    fun ext(f: File): String = f.extension.lowercase(Locale.ROOT)

    fun kind(f: File): Kind {
        val e = ext(f)
        return when {
            e in video -> Kind.VIDEO
            e in audio -> Kind.AUDIO
            e in image -> Kind.IMAGE
            else -> Kind.OTHER
        }
    }

    fun icon(f: File): String {
        if (f.isDirectory) return "\uD83D\uDCC1"
        return when (kind(f)) {
            Kind.VIDEO -> "\uD83C\uDFAC"
            Kind.AUDIO -> "\uD83C\uDFB5"
            Kind.IMAGE -> "\uD83D\uDDBC\uFE0F"
            Kind.OTHER -> when (ext(f)) {
                "zip", "rar", "7z", "apk" -> "\uD83D\uDCE6"
                else -> "\uD83D\uDCC4"
            }
        }
    }

    fun size(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var v = bytes.toDouble()
        var i = -1
        do {
            v /= 1024.0
            i++
        } while (v >= 1024.0 && i < units.size - 1)
        return String.format(Locale.US, if (v < 10) "%.1f %s" else "%.0f %s", v, units[i])
    }

    /** Strips characters that are unsafe in file names (and any ".." tricks). */
    fun cleanName(raw: String): String {
        var s = raw.trim().replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_")
        while (s.contains("..")) s = s.replace("..", "_")
        s = s.trimStart('.')
        return s.take(200)
    }

    /** If "name" already exists in dir, returns "name (1)", "name (2)" and so on. */
    fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val base = if (name.contains('.')) name.substringBeforeLast('.') else name
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var n = 1
        while (true) {
            f = File(dir, "$base ($n)$ext")
            if (!f.exists()) return f
            n++
        }
    }
}
