package com.arch.tv

import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.tv.TvContract

/** One card on the Continue playing row, already tidied up and ready to show. */
data class Card(
    val key: String,
    val title: String,
    val subtitle: String,
    val source: String,
    val progress: Float, // 0..1, or -1 when unknown / not applicable
    val imageUri: String?,
    val desc: String,
    val pkg: String,
    val intentUri: String?
)

/**
 * Reads Android TV's "Play next / Continue watching" list: the shows and films that
 * apps publish when you stop watching, or when a new episode is ready.
 */
object ContinueRepo {
    const val PERMISSION = "android.permission.READ_TV_LISTINGS"

    fun hasPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(PERMISSION) == PackageManager.PERMISSION_GRANTED

    private class Row(
        val pkg: String,
        val title: String?,
        val episodeTitle: String?,
        val season: String?,
        val episode: String?,
        val desc: String?,
        val poster: String?,
        val thumb: String?,
        val intent: String?,
        val pos: Long,
        val dur: Long,
        val engaged: Long,
        val type: Int // 0 continue, 1 next episode, 2 new, 3 watchlist
    )

    private fun Cursor.str(name: String): String? {
        val i = getColumnIndex(name)
        return if (i >= 0 && !isNull(i)) getString(i) else null
    }

    private fun Cursor.lng(name: String, def: Long = -1L): Long {
        val i = getColumnIndex(name)
        return if (i >= 0 && !isNull(i)) getLong(i) else def
    }

    private fun query(ctx: Context): List<Row> {
        val out = ArrayList<Row>()
        val c = try {
            ctx.contentResolver.query(TvContract.WatchNextPrograms.CONTENT_URI, null, null, null, null)
        } catch (e: Exception) {
            null
        } ?: return out
        c.use { cur ->
            while (cur.moveToNext()) {
                out += Row(
                    pkg = cur.str("package_name") ?: continue,
                    title = cur.str("title"),
                    episodeTitle = cur.str("episode_title"),
                    season = cur.str("season_display_number") ?: cur.str("season_number"),
                    episode = cur.str("episode_display_number") ?: cur.str("episode_number"),
                    desc = cur.str("short_description"),
                    poster = cur.str("poster_art_uri"),
                    thumb = cur.str("thumbnail_uri"),
                    intent = cur.str("intent_uri"),
                    pos = cur.lng("last_playback_position_millis", 0L),
                    dur = cur.lng("duration_millis", 0L),
                    engaged = cur.lng("last_engagement_time_utc_millis", 0L),
                    type = cur.lng("watch_next_type", 0L).toInt()
                )
            }
        }
        return out
    }

    fun cards(ctx: Context, fix: Boolean, hidden: Set<String>): List<Card> {
        val pm = ctx.packageManager
        val labels = HashMap<String, String>()
        fun label(pkg: String): String = labels.getOrPut(pkg) {
            try {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() }
            }
        }

        val rows = query(ctx)
            .filter { it.type != 3 } // skip the watchlist, keep continue / next / new
            .sortedWith(compareBy<Row>({ if (it.type == 0) 0 else 1 }, { -it.engaged }))

        return rows.mapNotNull { r ->
            val app = label(r.pkg)
            val key = r.pkg + "|" + (r.title ?: "") + "|" + (r.season ?: "") + "|" +
                (r.episode ?: "") + "|" + (r.episodeTitle ?: "")
            if (key in hidden) return@mapNotNull null

            val fixed = if (fix) {
                TitleFixer.fix(r.title, r.episodeTitle, r.season, r.episode, app)
            } else {
                TitleFixer.plain(r.title, r.episodeTitle)
            }
            if (fixed.title.isBlank()) return@mapNotNull null

            val progress = if (r.type != 1 && r.dur > 0 && r.pos > 0) {
                (r.pos.toFloat() / r.dur.toFloat()).coerceIn(0f, 1f)
            } else {
                -1f
            }
            val extra = when {
                r.type == 1 -> "Up next"
                r.type == 2 -> "New"
                r.dur > 0 && r.pos > 0 -> {
                    val left = (r.dur - r.pos) / 60_000
                    when {
                        left >= 60 -> "${left / 60}h ${left % 60}m left"
                        left > 0 -> "$left min left"
                        else -> ""
                    }
                }
                else -> ""
            }
            Card(
                key = key,
                title = fixed.title,
                subtitle = fixed.subtitle,
                source = if (extra.isEmpty()) app else "$app · $extra",
                progress = progress,
                imageUri = r.thumb ?: r.poster,
                desc = TitleFixer.clean(r.desc),
                pkg = r.pkg,
                intentUri = r.intent
            )
        }.take(20)
    }
}
