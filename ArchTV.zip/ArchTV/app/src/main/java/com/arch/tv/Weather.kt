package com.arch.tv

import org.json.JSONObject
import kotlin.math.roundToInt

data class WeatherInfo(
    val city: String,
    val temp: Int,
    val hi: Int,
    val lo: Int,
    val emoji: String,
    val desc: String,
    val fahrenheit: Boolean
)

/**
 * Finds your approximate location from your internet connection (IP address),
 * then asks Open-Meteo (free, no account) for the weather there.
 */
object WeatherRepo {

    private data class Loc(val lat: String, val lon: String, val city: String)

    fun fetch(p: Prefs): WeatherInfo? {
        val loc = location(p) ?: return null
        val f = p.fahrenheit
        val unit = if (f) "fahrenheit" else "celsius"
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${loc.lat}&longitude=${loc.lon}" +
            "&current=temperature_2m,weather_code,is_day" +
            "&daily=temperature_2m_max,temperature_2m_min" +
            "&temperature_unit=$unit&timezone=auto&forecast_days=1"
        val body = Net.get(url) ?: return null
        return try {
            val j = JSONObject(body)
            val cur = j.getJSONObject("current")
            val daily = j.getJSONObject("daily")
            val (emoji, desc) = describe(cur.getInt("weather_code"), cur.optInt("is_day", 1) == 1)
            WeatherInfo(
                city = loc.city,
                temp = cur.getDouble("temperature_2m").roundToInt(),
                hi = daily.getJSONArray("temperature_2m_max").getDouble(0).roundToInt(),
                lo = daily.getJSONArray("temperature_2m_min").getDouble(0).roundToInt(),
                emoji = emoji,
                desc = desc,
                fahrenheit = f
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun location(p: Prefs): Loc? {
        val lat = p.locLat
        val lon = p.locLon
        val age = System.currentTimeMillis() - p.locTime
        if (lat != null && lon != null && age < 6 * 3_600_000L) {
            return Loc(lat, lon, p.locCity ?: "")
        }
        val found = fromIpWho() ?: fromGeoJs()
        if (found != null) {
            p.locLat = found.lat
            p.locLon = found.lon
            p.locCity = found.city
            p.locTime = System.currentTimeMillis()
            return found
        }
        // offline or lookup failed: reuse the last known place if we have one
        return if (lat != null && lon != null) Loc(lat, lon, p.locCity ?: "") else null
    }

    private fun fromIpWho(): Loc? {
        val body = Net.get("https://ipwho.is/") ?: return null
        return try {
            val j = JSONObject(body)
            if (!j.optBoolean("success", false)) return null
            val lat = j.optDouble("latitude", Double.NaN)
            val lon = j.optDouble("longitude", Double.NaN)
            if (lat.isNaN() || lon.isNaN()) null else Loc(lat.toString(), lon.toString(), j.optString("city", ""))
        } catch (e: Exception) {
            null
        }
    }

    private fun fromGeoJs(): Loc? {
        val body = Net.get("https://get.geojs.io/v1/ip/geo.json") ?: return null
        return try {
            val j = JSONObject(body)
            val lat = j.optDouble("latitude", Double.NaN)
            val lon = j.optDouble("longitude", Double.NaN)
            if (lat.isNaN() || lon.isNaN()) null else Loc(lat.toString(), lon.toString(), j.optString("city", ""))
        } catch (e: Exception) {
            null
        }
    }

    private fun describe(code: Int, day: Boolean): Pair<String, String> = when (code) {
        0 -> (if (day) "☀️" else "🌙") to "Clear"
        1 -> (if (day) "🌤️" else "🌙") to "Mostly clear"
        2 -> "⛅" to "Partly cloudy"
        3 -> "☁️" to "Overcast"
        45, 48 -> "🌫️" to "Fog"
        51, 53, 55, 56, 57 -> "🌦️" to "Drizzle"
        61, 63, 65, 66, 67 -> "🌧️" to "Rain"
        71, 73, 75, 77 -> "🌨️" to "Snow"
        80, 81 -> "🌦️" to "Showers"
        82 -> "🌧️" to "Heavy showers"
        85, 86 -> "🌨️" to "Snow showers"
        95 -> "⛈️" to "Thunderstorm"
        96, 99 -> "⛈️" to "Thunderstorm, hail"
        else -> "🌡️" to "Weather"
    }
}
