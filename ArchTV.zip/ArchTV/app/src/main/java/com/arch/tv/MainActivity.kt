package com.arch.tv

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextClock
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var grid: RecyclerView
    private lateinit var cards: RecyclerView
    private lateinit var sectionLabel: TextView
    private lateinit var clock: TextClock
    private lateinit var date: TextClock
    private lateinit var clockBox: View
    private lateinit var dim: View
    private lateinit var heroBg: ImageView
    private lateinit var hero: View
    private lateinit var heroSource: TextView
    private lateinit var heroTitle: TextView
    private lateinit var heroSub: TextView
    private lateinit var heroDesc: TextView
    private lateinit var weatherBox: View
    private lateinit var weatherMain: TextView
    private lateinit var weatherSub: TextView
    private lateinit var slideshow: Slideshow

    private val adapter = AppAdapter(
        onClick = { launchApp(it) },
        onLongClick = { showAppMenu(it) }
    )
    private val cardAdapter = CardAdapter(
        onClick = { openCard(it) },
        onLongClick = { showCardMenu(it) },
        art = { appArt(it) }
    )
    private val worker = Executors.newSingleThreadExecutor()
    private val net = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    private var allApps: List<AppItem> = emptyList()
    private var lastWeather: WeatherInfo? = null
    private var lastWeatherAt = 0L
    private var heroKey: String? = null
    private var focusedCardsOnce = false

    private val weatherTick = object : Runnable {
        override fun run() {
            refreshWeather()
            handler.postDelayed(this, WEATHER_EVERY_MS)
        }
    }

    // Refresh the app list whenever an app is installed or removed
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = loadApps()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        setContentView(R.layout.activity_main)

        grid = findViewById(R.id.grid)
        cards = findViewById(R.id.cards)
        sectionLabel = findViewById(R.id.sectionLabel)
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        clockBox = findViewById(R.id.clockBox)
        dim = findViewById(R.id.dim)
        heroBg = findViewById(R.id.heroBg)
        hero = findViewById(R.id.hero)
        heroSource = findViewById(R.id.heroSource)
        heroTitle = findViewById(R.id.heroTitle)
        heroSub = findViewById(R.id.heroSub)
        heroDesc = findViewById(R.id.heroDesc)
        weatherBox = findViewById(R.id.weather)
        weatherMain = findViewById(R.id.weatherMain)
        weatherSub = findViewById(R.id.weatherSub)
        slideshow = Slideshow(this, findViewById(R.id.bgOld), findViewById(R.id.bgNew), prefs)
        window.decorView.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            GlassBackdrop.setWindow(r - l, b - t)
        }

        grid.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        grid.adapter = adapter
        grid.itemAnimator = null

        cards.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        cards.adapter = cardAdapter
        cards.itemAnimator = null

        findViewById<View>(R.id.settings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        // Focusing a Continue playing card shows its details (and picture) big on screen
        window.decorView.viewTreeObserver.addOnGlobalFocusChangeListener { _, newFocus ->
            onFocusMoved(newFocus)
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        loadApps()
    }

    override fun onResume() {
        super.onResume()
        applySettings()
    }

    override fun onPause() {
        hideHero()
        slideshow.stop()
        handler.removeCallbacks(weatherTick)
        super.onPause()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Home pressed while already here: jump back to the start
        cards.scrollToPosition(0)
        grid.scrollToPosition(0)
        val target = if (cards.visibility == View.VISIBLE) cards else grid
        target.postDelayed({ target.getChildAt(0)?.requestFocus() }, 120)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // A launcher should never close itself
    }

    override fun onDestroy() {
        unregisterReceiver(packageReceiver)
        slideshow.stop()
        worker.shutdown()
        net.shutdown()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        loadContinue()
    }

    // ---------- settings -> screen ----------

    private fun applySettings() {
        dim.alpha = prefs.dim / 100f
        GlassBackdrop.updateStrength(
            when (prefs.glass) {
                0 -> 0f
                1 -> 0.6f
                else -> 1f
            }
        )

        val fmt = if (prefs.clock24) "HH:mm" else "h:mm"
        clock.format12Hour = fmt
        clock.format24Hour = fmt
        date.visibility = if (prefs.showDate) View.VISIBLE else View.GONE

        adapter.configure(
            sizeDp = when (prefs.iconSize) {
                0 -> 56
                2 -> 92
                else -> 72
            },
            labelsOnFocus = prefs.labelsOnFocus
        )
        applyAppList()

        if (prefs.natureBg) slideshow.start() else slideshow.stop(clear = true)

        handler.removeCallbacks(weatherTick)
        if (prefs.weatherOn) {
            if (lastWeather?.fahrenheit != prefs.fahrenheit) lastWeather = null
            lastWeather?.let { showWeather(it) }
            val age = System.currentTimeMillis() - lastWeatherAt
            val wait = if (lastWeather != null && age < WEATHER_MIN_GAP_MS) WEATHER_MIN_GAP_MS - age else 0L
            handler.postDelayed(weatherTick, wait)
        } else {
            weatherBox.visibility = View.GONE
        }

        if (prefs.continueOn) {
            if (!ContinueRepo.hasPermission(this) && !prefs.askedPerm) {
                prefs.askedPerm = true
                requestPermissions(arrayOf(ContinueRepo.PERMISSION), 42)
            }
            loadContinue()
        } else {
            setCards(emptyList())
        }
    }

    // ---------- apps ----------

    private fun loadApps() {
        worker.execute {
            val apps = AppRepo.queryAll(this)
            runOnUiThread {
                allApps = apps
                applyAppList()
            }
        }
    }

    private fun applyAppList() {
        val hidden = prefs.hidden
        val pinned = prefs.pinned
        val visible = allApps.filter { it.pkg !in hidden }
        val rest = visible.filter { it.pkg !in pinned }.let { list ->
            if (prefs.newestFirst) list.sortedByDescending { it.installed }
            else list.sortedBy { it.label.lowercase() }
        }
        val front = pinned.mapNotNull { p -> visible.firstOrNull { it.pkg == p } }
        if (adapter.submit(front + rest) && cards.visibility != View.VISIBLE) {
            grid.postDelayed({ grid.getChildAt(0)?.requestFocus() }, 120)
        }
    }

    private fun launchApp(item: AppItem) {
        try {
            startActivity(item.launch)
        } catch (_: Exception) {
            // app vanished or can't be opened; ignore
        }
    }

    // Long-press an app: pin, hide, or open its info page
    private fun showAppMenu(item: AppItem) {
        val pinned = prefs.pinned
        val isPinned = item.pkg in pinned
        val options = arrayOf(
            if (isPinned) "Unpin from front" else "Pin to front",
            "Hide from home",
            "App info / uninstall"
        )
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(item.label)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        prefs.pinned = if (isPinned) pinned - item.pkg else pinned + item.pkg
                        applyAppList()
                    }
                    1 -> {
                        prefs.hidden = prefs.hidden + item.pkg
                        applyAppList()
                    }
                    2 -> startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${item.pkg}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }
            .show()
    }

    // ---------- continue playing ----------

    private fun loadContinue() {
        if (!prefs.continueOn || !ContinueRepo.hasPermission(this)) {
            setCards(emptyList())
            return
        }
        val fix = prefs.fixTitles
        val hidden = prefs.hiddenContinue
        net.execute {
            val list = try {
                ContinueRepo.cards(this, fix, hidden)
            } catch (e: Exception) {
                emptyList()
            }
            runOnUiThread { setCards(list) }
        }
    }

    private fun setCards(list: List<Card>) {
        val changed = cardAdapter.submit(list)
        val show = prefs.continueOn && list.isNotEmpty()
        cards.visibility = if (show) View.VISIBLE else View.GONE
        sectionLabel.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) hideHero()
        if (show && changed && !focusedCardsOnce) {
            focusedCardsOnce = true
            cards.postDelayed({ cards.getChildAt(0)?.requestFocus() }, 150)
        }
    }

    private fun appArt(pkg: String): Drawable? = try {
        packageManager.getApplicationBanner(pkg) ?: packageManager.getApplicationIcon(pkg)
    } catch (e: Exception) {
        null
    }

    private fun openCard(c: Card) {
        try {
            val uri = c.intentUri
            if (uri != null) {
                val i = Intent.parseUri(uri, Intent.URI_INTENT_SCHEME)
                i.selector = null
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                return
            }
        } catch (_: Exception) {
            // fall through and just open the app
        }
        try {
            val i = packageManager.getLeanbackLaunchIntentForPackage(c.pkg)
                ?: packageManager.getLaunchIntentForPackage(c.pkg)
            if (i != null) startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }

    private fun showCardMenu(c: Card) {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(c.title)
            .setItems(arrayOf("Hide from Continue playing", "App info")) { _, which ->
                when (which) {
                    0 -> {
                        prefs.hiddenContinue = prefs.hiddenContinue + c.key
                        loadContinue()
                    }
                    1 -> startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${c.pkg}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }
            .show()
    }

    // ---------- hero (big details for the focused card) ----------

    private fun onFocusMoved(v: View?) {
        val vh = if (v != null) cards.findContainingViewHolder(v) else null
        val pos = vh?.bindingAdapterPosition ?: -1
        val items = cardAdapter.items
        if (pos in items.indices) showHero(items[pos]) else hideHero()
    }

    private fun showHero(c: Card) {
        if (heroKey == c.key) return
        heroKey = c.key
        heroSource.text = c.source.uppercase()
        heroTitle.text = c.title
        heroSub.text = c.subtitle
        heroSub.visibility = if (c.subtitle.isEmpty()) View.GONE else View.VISIBLE
        heroDesc.text = c.desc
        heroDesc.visibility = if (c.desc.isEmpty()) View.GONE else View.VISIBLE
        hero.animate().alpha(1f).setDuration(200).start()
        clockBox.animate().alpha(0f).setDuration(200).start()

        heroBg.animate().alpha(0f).setDuration(150).start()
        GlassBackdrop.setOver(null)
        val uri = c.imageUri
        if (prefs.backdrop && uri != null) {
            ImageLoader.load(this, uri, 1280) { bmp ->
                // only wide pictures make a good backdrop; tall posters would look stretched
                if (heroKey == c.key && bmp != null && bmp.width >= bmp.height * 1.3f) {
                    heroBg.setImageBitmap(bmp)
                    heroBg.animate().alpha(1f).setDuration(350).start()
                    GlassBackdrop.setOver(bmp)
                }
            }
        }
    }

    private fun hideHero() {
        if (heroKey == null) return
        heroKey = null
        hero.animate().alpha(0f).setDuration(200).start()
        clockBox.animate().alpha(1f).setDuration(200).start()
        heroBg.animate().alpha(0f).setDuration(200).start()
        GlassBackdrop.setOver(null)
    }

    // ---------- weather ----------

    private fun refreshWeather() {
        net.execute {
            val w = WeatherRepo.fetch(prefs)
            runOnUiThread {
                if (w != null && prefs.weatherOn) {
                    lastWeather = w
                    lastWeatherAt = System.currentTimeMillis()
                    showWeather(w)
                }
            }
        }
    }

    private fun showWeather(w: WeatherInfo) {
        weatherBox.visibility = View.VISIBLE
        weatherMain.text = "${w.emoji} ${w.temp}°"
        val place = if (w.city.isNotEmpty()) "${w.city} · " else ""
        weatherSub.text = "$place${w.desc} · H ${w.hi}°  L ${w.lo}°"
    }

    companion object {
        private const val WEATHER_EVERY_MS = 30 * 60 * 1000L
        private const val WEATHER_MIN_GAP_MS = 10 * 60 * 1000L
    }
}

class AppAdapter(
    private val onClick: (AppItem) -> Unit,
    private val onLongClick: (AppItem) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppItem> = emptyList()
    private var sizeDp = 72
    private var labelsOnFocus = false

    fun configure(sizeDp: Int, labelsOnFocus: Boolean) {
        if (this.sizeDp != sizeDp || this.labelsOnFocus != labelsOnFocus) {
            this.sizeDp = sizeDp
            this.labelsOnFocus = labelsOnFocus
            notifyDataSetChanged()
        }
    }

    /** Returns true if the set/order of apps changed (so the row was rebuilt). */
    fun submit(newItems: List<AppItem>): Boolean {
        val changed = newItems.map { it.pkg } != items.map { it.pkg }
        items = newItems
        if (changed) notifyDataSetChanged()
        return changed
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tile: FrameLayout = view.findViewById(R.id.tile)
        val icon: ImageView = view.findViewById(R.id.icon)
        val label: TextView = view.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        v.setOnFocusChangeListener { view, hasFocus ->
            val s = if (hasFocus) 1.15f else 1f
            view.animate().scaleX(s).scaleY(s).setDuration(130).start()
            if (labelsOnFocus) {
                view.findViewById<View>(R.id.label)
                    .animate().alpha(if (hasFocus) 1f else 0f).setDuration(130).start()
            }
        }
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val px = (sizeDp * holder.itemView.resources.displayMetrics.density).toInt()
        holder.tile.layoutParams = holder.tile.layoutParams.apply { width = px; height = px }
        holder.label.layoutParams = holder.label.layoutParams.apply { width = px }
        holder.icon.setImageDrawable(item.icon)
        holder.label.text = item.label
        holder.label.alpha = if (labelsOnFocus && !holder.itemView.hasFocus()) 0f else 1f
        holder.itemView.setOnClickListener { onClick(item) }
        holder.itemView.setOnLongClickListener { onLongClick(item); true }
    }

    override fun getItemCount() = items.size
}
