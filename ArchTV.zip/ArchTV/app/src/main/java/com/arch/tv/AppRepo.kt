package com.arch.tv

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable

data class AppItem(
    val label: String,
    val pkg: String,
    val launch: Intent,
    val icon: Drawable,
    val installed: Long
)

object AppRepo {
    /** Every launchable app on the device (TV apps first, then regular apps), except Arch TV itself. */
    fun queryAll(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val tvApps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0
        )
        val otherApps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )

        val seen = HashSet<String>()
        val items = ArrayList<AppItem>()
        for (ri in tvApps + otherApps) {
            val pkg = ri.activityInfo.packageName
            if (pkg == ctx.packageName || !seen.add(pkg)) continue
            val intent = pm.getLeanbackLaunchIntentForPackage(pkg)
                ?: pm.getLaunchIntentForPackage(pkg)
                ?: continue
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val installed = try {
                pm.getPackageInfo(pkg, 0).firstInstallTime
            } catch (e: Exception) {
                0L
            }
            items += AppItem(ri.loadLabel(pm).toString(), pkg, intent, ri.loadIcon(pm), installed)
        }
        return items
    }
}
