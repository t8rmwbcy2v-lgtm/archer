package com.arch.tv

/** The web page you open on your phone or laptop to send photos to Arch TV. */
object Page {
    const val HTML = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Arch TV photos</title>
<style>
:root { --bg:#0e1116; --card:#171c24; --line:#2a3140; --text:#f2f5f9; --dim:#9aa4b2; --accent:#3d7bff; --bad:#ff6b6b; --good:#4ade80; }
* { box-sizing: border-box; }
body { margin:0; background:var(--bg); color:var(--text); font:16px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif; }
h1 { margin:0; font-size:22px; font-weight:600; }
a { color:inherit; }
.card { max-width:360px; margin:12vh auto 0; padding:28px; background:var(--card); border:1px solid var(--line); border-radius:18px; text-align:center; }
.card p { color:var(--dim); }
input#pin { width:100%; padding:14px; font-size:28px; letter-spacing:10px; text-align:center; background:var(--bg); color:var(--text); border:1px solid var(--line); border-radius:12px; }
button, .btn { display:inline-block; padding:10px 16px; border:0; border-radius:10px; background:var(--accent); color:#fff; font:inherit; font-weight:600; cursor:pointer; }
button.x { background:transparent; color:var(--bad); border:1px solid var(--line); padding:6px 10px; font-weight:500; }
#go { margin-top:16px; width:100%; }
.err { color:var(--bad); min-height:1.4em; }
#app { display:none; max-width:820px; margin:0 auto; padding:20px 16px 60px; }
header { display:flex; justify-content:space-between; align-items:baseline; margin-bottom:12px; }
#free { color:var(--dim); font-size:14px; }
#crumbs { margin:8px 0 14px; color:var(--dim); }
.crumb { text-decoration:none; color:var(--text); }
.drop { border:2px dashed var(--line); border-radius:16px; padding:22px; text-align:center; color:var(--dim); margin-bottom:14px; }
.drop.over { border-color:var(--accent); background:rgba(61,123,255,.08); }
.drop .btn { margin:6px 4px 0; }
.up { background:var(--card); border:1px solid var(--line); border-radius:10px; padding:10px 12px; margin-bottom:8px; font-size:14px; }
.up.done .upstat { color:var(--good); }
.up.fail .upstat { color:var(--bad); }
.upname { display:block; word-break:break-all; margin-bottom:6px; }
.bar { height:6px; background:var(--bg); border-radius:3px; overflow:hidden; }
.fill { height:100%; width:0; background:var(--accent); }
.upstat { display:block; margin-top:6px; color:var(--dim); }
ul#list { list-style:none; margin:16px 0 0; padding:0; }
.row { display:flex; align-items:center; gap:12px; padding:12px 10px; border-bottom:1px solid var(--line); }
.row .ico { font-size:22px; }
.row .name { flex:1; text-decoration:none; word-break:break-all; }
.row .size { color:var(--dim); font-size:14px; white-space:nowrap; }
li.empty { color:var(--dim); padding:20px 10px; }
</style>
</head>
<body>
<div id="login" class="card">
  <h1>Arch TV photos</h1>
  <p>Enter the PIN shown on your TV</p>
  <input id="pin" inputmode="numeric" maxlength="4" autocomplete="off" autofocus>
  <button id="go">Connect</button>
  <p id="loginErr" class="err"></p>
</div>

<div id="app">
  <header><h1>Arch TV photos</h1><span id="free"></span></header>
  <div id="crumbs"></div>
  <div id="drop" class="drop">
    Drop photos here
    <div>
      <label class="btn">Choose photos<input type="file" id="pick" accept="image/*" multiple hidden></label>
      <button id="mk" style="display:none">New folder</button>
    </div>
  </div>
  <div id="uploads"></div>
  <ul id="list"></ul>
</div>

<script>
var PIN = '';
var CUR = '';
var FREE = 0;
var queue = [];
var busy = false;

function el(tag, cls, text) {
  var e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}
function q(id) { return document.getElementById(id); }
function fmt(n) {
  if (n < 1024) return n + ' B';
  var u = ['KB', 'MB', 'GB', 'TB'];
  var i = -1;
  do { n = n / 1024; i++; } while (n >= 1024 && i < 3);
  return n.toFixed(n < 10 ? 1 : 0) + ' ' + u[i];
}
function join(a, b) { return a ? a + '/' + b : b; }

function api(action, params, opts) {
  var qs = 'pin=' + encodeURIComponent(PIN);
  for (var k in params) qs += '&' + k + '=' + encodeURIComponent(params[k]);
  return fetch('/api/' + action + '?' + qs, opts || {}).then(function (r) {
    return r.json().then(function (j) {
      if (!r.ok) throw new Error(j.error || 'Something went wrong');
      return j;
    });
  });
}

function load(path) {
  CUR = path;
  return api('list', { path: path }).then(render).catch(function (e) { alert(e.message); });
}

function render(j) {
  FREE = j.free;
  q('free').textContent = fmt(j.free) + ' free on the TV';
  var c = q('crumbs');
  c.innerHTML = '';
  var root = el('a', 'crumb', 'Files');
  root.href = '#';
  root.onclick = function (ev) { ev.preventDefault(); load(''); };
  c.appendChild(root);
  var acc = '';
  CUR.split('/').filter(Boolean).forEach(function (seg) {
    acc = join(acc, seg);
    var target = acc;
    c.appendChild(el('span', 'sep', '  /  '));
    var a = el('a', 'crumb', seg);
    a.href = '#';
    a.onclick = function (ev) { ev.preventDefault(); load(target); };
    c.appendChild(a);
  });
  var ul = q('list');
  ul.innerHTML = '';
  if (!j.items.length) ul.appendChild(el('li', 'empty', 'Nothing here yet.'));
  j.items.forEach(function (it) {
    var li = el('li', 'row');
    var p = join(CUR, it.name);
    li.appendChild(el('span', 'ico', it.dir ? '\uD83D\uDCC1' : '\uD83D\uDCC4'));
    var name = el('a', 'name', it.name);
    if (it.dir) {
      name.href = '#';
      name.onclick = function (ev) { ev.preventDefault(); load(p); };
    } else {
      name.href = '/api/download?pin=' + encodeURIComponent(PIN) + '&path=' + encodeURIComponent(p);
    }
    li.appendChild(name);
    li.appendChild(el('span', 'size', it.dir ? '' : fmt(it.size)));
    var del = el('button', 'x', 'Delete');
    del.onclick = function () {
      if (confirm('Delete ' + it.name + '?')) {
        api('delete', { path: p }, { method: 'POST' })
          .then(function () { load(CUR); })
          .catch(function (e) { alert(e.message); });
      }
    };
    li.appendChild(del);
    ul.appendChild(li);
  });
}

function enqueue(files) {
  for (var i = 0; i < files.length; i++) queue.push(files[i]);
  pump();
}

function pump() {
  if (busy || !queue.length) return;
  busy = true;
  var f = queue.shift();
  var dest = CUR;
  if (!/\.(jpe?g|png|webp|gif|bmp)$/i.test(f.name)) {
    var bad = el('div', 'up fail');
    bad.appendChild(el('span', 'upname', f.name));
    bad.appendChild(el('span', 'upstat', 'Only photos can be added here'));
    q('uploads').insertBefore(bad, q('uploads').firstChild);
    busy = false;
    pump();
    return;
  }
  var row = el('div', 'up');
  var fill = el('div', 'fill');
  var bar = el('div', 'bar');
  var st = el('span', 'upstat', 'Waiting...');
  bar.appendChild(fill);
  row.appendChild(el('span', 'upname', f.name));
  row.appendChild(bar);
  row.appendChild(st);
  q('uploads').insertBefore(row, q('uploads').firstChild);

  if (f.size > FREE - 50 * 1048576) {
    st.textContent = 'Not enough space left on the TV';
    row.className = 'up fail';
    busy = false;
    pump();
    return;
  }

  var xhr = new XMLHttpRequest();
  xhr.open('PUT', '/api/upload?pin=' + encodeURIComponent(PIN) + '&path=' + encodeURIComponent(dest) + '&name=' + encodeURIComponent(f.name));
  xhr.upload.onprogress = function (ev) {
    if (ev.lengthComputable) {
      var pct = Math.round(ev.loaded / ev.total * 100);
      fill.style.width = pct + '%';
      st.textContent = pct + '%  (' + fmt(ev.loaded) + ' of ' + fmt(ev.total) + ')';
    }
  };
  xhr.onload = function () {
    if (xhr.status === 200) {
      fill.style.width = '100%';
      st.textContent = 'Done';
      row.className = 'up done';
    } else {
      var msg = 'Failed';
      try { msg = JSON.parse(xhr.responseText).error || msg; } catch (e) {}
      st.textContent = msg;
      row.className = 'up fail';
    }
    busy = false;
    if (CUR === dest) load(CUR);
    pump();
  };
  xhr.onerror = function () {
    st.textContent = 'Connection lost';
    row.className = 'up fail';
    busy = false;
    pump();
  };
  xhr.send(f);
}

function connect() {
  PIN = q('pin').value.trim();
  q('loginErr').textContent = '';
  api('list', { path: '' }).then(function (j) {
    q('login').style.display = 'none';
    q('app').style.display = 'block';
    render(j);
  }).catch(function (e) { q('loginErr').textContent = e.message; });
}

q('go').onclick = connect;
q('pin').onkeydown = function (e) { if (e.key === 'Enter') connect(); };
q('pick').onchange = function () { enqueue(this.files); this.value = ''; };
q('mk').onclick = function () {
  var n = prompt('New folder name');
  if (!n) return;
  api('mkdir', { path: CUR, name: n }, { method: 'POST' })
    .then(function () { load(CUR); })
    .catch(function (e) { alert(e.message); });
};
var drop = q('drop');
['dragenter', 'dragover'].forEach(function (t) {
  drop.addEventListener(t, function (e) { e.preventDefault(); drop.classList.add('over'); });
});
['dragleave', 'drop'].forEach(function (t) {
  drop.addEventListener(t, function (e) { e.preventDefault(); drop.classList.remove('over'); });
});
drop.addEventListener('drop', function (e) { enqueue(e.dataTransfer.files); });
document.addEventListener('dragover', function (e) { e.preventDefault(); });
document.addEventListener('drop', function (e) { e.preventDefault(); });
</script>
</body>
</html>"""
}
