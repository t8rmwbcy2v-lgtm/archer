package com.arch.tv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout
import kotlin.math.min

/**
 * A panel that looks like frosted "liquid glass": it shows a blurred, slightly boosted copy of
 * the picture behind it, with a soft sheen and a bright edge that catches the light.
 *
 * glassMode "always" = always drawn. "focus" = only drawn when focused (or selected).
 */
class GlassLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : FrameLayout(context, attrs, defStyle) {

    private val density = resources.displayMetrics.density
    private var radius = 20f * density
    private var mode = 0

    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(1.35f) })
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val clip = Path()
    private val rimPath = Path()
    private val rect = RectF()
    private val bmpMatrix = Matrix()
    private val loc = IntArray(2)
    private var rimGradient: LinearGradient? = null

    init {
        setWillNotDraw(false)
        val ta = context.obtainStyledAttributes(attrs, R.styleable.GlassLayout)
        try {
            radius = ta.getDimension(R.styleable.GlassLayout_glassRadius, radius)
            mode = ta.getInt(R.styleable.GlassLayout_glassMode, 0)
        } finally {
            ta.recycle()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        GlassBackdrop.register(this)
    }

    override fun onDetachedFromWindow() {
        GlassBackdrop.unregister(this)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val wf = w.toFloat()
        val hf = h.toFloat()
        val r = min(radius, min(wf, hf) / 2f)
        rect.set(0f, 0f, wf, hf)
        clip.reset()
        clip.addRoundRect(rect, r, r, Path.Direction.CW)

        val inset = 1.5f * density / 2f
        rimPath.reset()
        rimPath.addRoundRect(
            RectF(inset, inset, wf - inset, hf - inset),
            r - inset, r - inset, Path.Direction.CW
        )
        sheen.shader = LinearGradient(
            0f, 0f, wf * 0.85f, hf * 0.95f,
            intArrayOf(Color.argb(85, 255, 255, 255), Color.argb(18, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            floatArrayOf(0f, 0.4f, 0.75f), Shader.TileMode.CLAMP
        )
        rimGradient = LinearGradient(
            0f, 0f, wf, hf,
            Color.argb(230, 255, 255, 255), Color.argb(50, 255, 255, 255), Shader.TileMode.CLAMP
        )
    }

    override fun drawableStateChanged() {
        super.drawableStateChanged()
        invalidate()
    }

    override fun requestChildFocus(child: View?, focused: View?) {
        super.requestChildFocus(child, focused)
        invalidate()
    }

    override fun clearChildFocus(child: View?) {
        super.clearChildFocus(child)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val focused = hasFocus() || drawableState.contains(android.R.attr.state_focused)
        val selected = isSelected
        if (mode == 1 && !focused && !selected) return

        val s = GlassBackdrop.strength
        c.save()
        c.clipPath(clip)

        val cur = GlassBackdrop.cur
        if (s > 0f && cur != null) {
            getLocationInWindow(loc)
            bmpMatrix.setScale(GlassBackdrop.DS.toFloat(), GlassBackdrop.DS.toFloat())
            bmpMatrix.postTranslate(-loc[0].toFloat(), -loc[1].toFloat())
            val prev = GlassBackdrop.prev
            val fade = GlassBackdrop.fade
            if (prev != null && fade < 1f) {
                bmpPaint.alpha = 255
                c.drawBitmap(prev, bmpMatrix, bmpPaint)
                bmpPaint.alpha = (fade * 255).toInt()
                c.drawBitmap(cur, bmpMatrix, bmpPaint)
            } else {
                bmpPaint.alpha = 255
                c.drawBitmap(cur, bmpMatrix, bmpPaint)
            }
        }

        // tint: smoked enough that white text stays easy to read
        fill.shader = null
        fill.color = if (s > 0f && cur != null) Color.argb((60 + 20 * s).toInt(), 0, 0, 0) else Color.argb(120, 0, 0, 0)
        c.drawRect(rect, fill)
        if (s > 0f) {
            fill.color = Color.argb((14 + 10 * s).toInt(), 255, 255, 255)
            c.drawRect(rect, fill)
            sheen.alpha = (255 * s).toInt()
            c.drawRect(rect, sheen)
        }
        if (focused) {
            fill.color = Color.argb(70, 255, 255, 255)
            c.drawRect(rect, fill)
        } else if (selected) {
            fill.color = Color.argb(38, 255, 255, 255)
            c.drawRect(rect, fill)
        }
        c.restore()

        // the bright edge
        if (focused) {
            rim.shader = null
            rim.color = Color.WHITE
            rim.strokeWidth = 3f * density
        } else {
            rim.shader = rimGradient
            rim.strokeWidth = 1.5f * density
            rim.alpha = (80 + 175 * s).toInt()
        }
        c.drawPath(rimPath, rim)
    }
}
