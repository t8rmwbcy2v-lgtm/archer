package com.arch.tv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.io.File
import java.util.concurrent.Executors

/** Loads poster art from web links (cached on disk) or from content:// links, with a small memory cache. */
object ImageLoader {
    private val cache = object : LruCache<String, Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val io = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    /** The callback always runs on the main thread. bmp is null if the picture couldn't be loaded. */
    fun load(ctx: Context, uri: String, maxW: Int, cb: (Bitmap?) -> Unit) {
        val key = "$maxW|$uri"
        val hit = cache.get(key)
        if (hit != null) {
            cb(hit)
            return
        }
        val app = ctx.applicationContext
        io.execute {
            val bmp = try {
                fetch(app, uri, maxW)
            } catch (t: Throwable) {
                null
            }
            if (bmp != null) cache.put(key, bmp)
            main.post { cb(bmp) }
        }
    }

    private fun fetch(ctx: Context, uriStr: String, maxW: Int): Bitmap? {
        val uri = Uri.parse(uriStr)
        return when (uri.scheme) {
            "http", "https" -> {
                val dir = File(ctx.cacheDir, "img").apply { mkdirs() }
                val f = File(dir, Integer.toHexString(uriStr.hashCode()) + ".img")
                if (!f.exists() || f.length() < 200) {
                    if (!Net.download(uriStr, f)) {
                        f.delete()
                        return null
                    }
                    trim(dir)
                }
                decodeFile(f.path, maxW)
            }
            "content", "android.resource", "file" -> {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                ctx.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply {
                        inSampleSize = sampleFor(bounds.outWidth, maxW)
                    })
                }
            }
            else -> null
        }
    }

    /** Decodes a picture file at a sensible size and turns phone photos the right way up. */
    fun decodeFile(path: String, maxW: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply {
            inSampleSize = sampleFor(bounds.outWidth, maxW)
        }) ?: return null
        val degrees = try {
            when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } catch (e: Exception) {
            0f
        }
        if (degrees == 0f) return bmp
        val m = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    private fun sampleFor(width: Int, maxW: Int): Int {
        var s = 1
        while (width / (s * 2) >= maxW) s *= 2
        return s
    }

    private fun trim(dir: File) {
        val files = dir.listFiles() ?: return
        files.sortedByDescending { it.lastModified() }.drop(80).forEach { it.delete() }
    }
}
